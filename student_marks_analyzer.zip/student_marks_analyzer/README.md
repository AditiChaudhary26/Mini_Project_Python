# Student Marks Analyzer (Python + Flask)

A website that analyses student marks: total, percentage, grade, pass/fail, class rank,
class statistics, and Word/CSV reports. Works offline (no CDN, no internet needed).

## Run
```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 and click **Load Demo Data** (20 sample students).

## Features
- Add / edit / delete students, search and sort
- Import marks from CSV (`sample_data.csv` shows the format), export results as CSV
- Dashboard: class average, pass %, topper, grade distribution, subject-wise stats
- Report card per student (compared with class average)
- Download **Word (.docx)** class report and student report cards

## Customise
Edit the top of `analyzer.py`: `SUBJECTS`, `MAX_MARKS`, `PASS_MARKS`, `GRADES`.
(Delete `students.db` after changing the number of subjects so the table is recreated.)

## Files
app.py (routes, validation) · analyzer.py (logic) · database.py (SQLite) ·
report.py (Word reports) · templates/ · static/style.css · sample_data.csv

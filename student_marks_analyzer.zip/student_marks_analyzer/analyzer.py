"""
analyzer.py - Core logic of the Student Marks Analyzer.
Pure Python (no Flask code here), so it is easy to test and explain in a viva.
"""
from statistics import mean, median, pstdev

# ---------- Configuration (change these to adapt the project) ----------
SUBJECTS = ["Mathematics", "Physics", "Chemistry", "English", "Computer Science"]
MAX_MARKS = 100          # maximum marks per subject
PASS_MARKS = 40          # minimum marks needed in EACH subject to pass
GRADES = [(90, "O"), (80, "A+"), (70, "A"), (60, "B"), (50, "C"), (40, "D"), (0, "F")]
GRADE_ORDER = [g for _, g in GRADES]


def grade_for(percentage):
    """Return the letter grade for a percentage."""
    for cutoff, grade in GRADES:
        if percentage >= cutoff:
            return grade
    return "F"


def analyse_student(student):
    """Take one student record (dict with m1..mN) and add computed fields."""
    marks = [student[f"m{i + 1}"] for i in range(len(SUBJECTS))]
    total = sum(marks)
    percentage = round(total / (MAX_MARKS * len(SUBJECTS)) * 100, 2)
    failed = [SUBJECTS[i] for i, m in enumerate(marks) if m < PASS_MARKS]
    result = "FAIL" if failed else "PASS"
    grade = "F" if failed else grade_for(percentage)
    out = dict(student)
    out.update(marks=marks, total=total, percentage=percentage,
               grade=grade, result=result, failed_subjects=failed)
    return out


def rank_students(analysed):
    """Sort by total marks (high to low) and add a 'rank' field.
    Students with equal totals share the same rank (1, 2, 2, 4 ...)."""
    ordered = sorted(analysed, key=lambda s: (-s["total"], s["name"].lower()))
    previous_total, previous_rank = None, 0
    for position, s in enumerate(ordered, start=1):
        if s["total"] == previous_total:
            s["rank"] = previous_rank
        else:
            s["rank"] = previous_rank = position
            previous_total = s["total"]
    return ordered


def class_summary(analysed):
    """Overall statistics for the whole class. Returns None if there is no data."""
    if not analysed:
        return None
    n = len(analysed)
    percentages = [s["percentage"] for s in analysed]
    passed = sum(1 for s in analysed if s["result"] == "PASS")
    ranked = sorted(analysed, key=lambda s: -s["total"])

    grade_counts = {g: 0 for g in GRADE_ORDER}
    for s in analysed:
        grade_counts[s["grade"]] += 1

    subject_stats = []
    for i, subject in enumerate(SUBJECTS):
        col = [s["marks"][i] for s in analysed]
        subject_stats.append({
            "subject": subject,
            "average": round(mean(col), 2),
            "highest": max(col),
            "lowest": min(col),
            "pass_percent": round(sum(1 for m in col if m >= PASS_MARKS) / n * 100, 1),
        })

    return {
        "count": n,
        "passed": passed,
        "failed": n - passed,
        "pass_percent": round(passed / n * 100, 1),
        "average_percentage": round(mean(percentages), 2),
        "median_percentage": round(median(percentages), 2),
        "std_dev": round(pstdev(percentages), 2),
        "topper": ranked[0],
        "highest_percentage": max(percentages),
        "lowest_percentage": min(percentages),
        "grade_counts": grade_counts,
        "subject_stats": subject_stats,
        "best_subject": max(subject_stats, key=lambda x: x["average"])["subject"],
        "weakest_subject": min(subject_stats, key=lambda x: x["average"])["subject"],
    }

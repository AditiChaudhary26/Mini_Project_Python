"""
app.py - Student Marks Analyzer (Flask web application)
Run:  python app.py      then open  http://127.0.0.1:5000
"""
import csv
import io
import os
from flask import (Flask, Response, abort, flash, redirect, render_template,
                   request, send_file, url_for)
import analyzer
import database as db
from report import class_report_docx, student_report_docx

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["DATABASE"] = os.path.join(app.root_path, "students.db")
app.teardown_appcontext(db.close_db)

DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


@app.context_processor
def inject_config():
    return dict(SUBJECTS=analyzer.SUBJECTS, MAX_MARKS=analyzer.MAX_MARKS,
                PASS_MARKS=analyzer.PASS_MARKS)


# ------------------------------------------------------------------ validation
def validate(form):
    """Check form input. Returns (clean_data, list_of_errors)."""
    errors = []
    roll_no = form.get("roll_no", "").strip().upper()
    name = form.get("name", "").strip()
    branch = form.get("branch", "").strip()
    if not roll_no:
        errors.append("Roll number is required.")
    if not name:
        errors.append("Student name is required.")
    marks = []
    for i, subject in enumerate(analyzer.SUBJECTS):
        raw = form.get(f"m{i + 1}", "").strip()
        try:
            value = int(raw)
        except ValueError:
            errors.append(f"{subject}: please enter a whole number.")
            continue
        if not 0 <= value <= analyzer.MAX_MARKS:
            errors.append(f"{subject}: marks must be between 0 and {analyzer.MAX_MARKS}.")
        marks.append(value)
    return dict(roll_no=roll_no, name=name, branch=branch, marks=marks), errors


# ---------------------------------------------------------------------- pages
@app.route("/")
def dashboard():
    students = db.all_students()
    summary = analyzer.class_summary(students)
    return render_template("dashboard.html", summary=summary, students=students)


@app.route("/students")
def students_list():
    q = request.args.get("q", "").strip().lower()
    sort = request.args.get("sort", "rank")
    students = db.all_students()
    if q:
        students = [s for s in students
                    if q in s["name"].lower() or q in s["roll_no"].lower()
                    or q in s["branch"].lower()]
    keys = {"rank": lambda s: s["rank"], "name": lambda s: s["name"].lower(),
            "roll": lambda s: s["roll_no"], "percentage": lambda s: -s["percentage"]}
    students.sort(key=keys.get(sort, keys["rank"]))
    return render_template("students.html", students=students, q=q, sort=sort)


@app.route("/students/add", methods=["GET", "POST"])
def add_student():
    if request.method == "POST":
        data, errors = validate(request.form)
        if not errors:
            try:
                db.save_student(data)
                flash(f"Student {data['name']} added successfully.", "success")
                return redirect(url_for("students_list"))
            except Exception:
                errors.append(f"Roll number {data['roll_no']} already exists.")
        for e in errors:
            flash(e, "error")
        return render_template("student_form.html", mode="Add", values=request.form)
    return render_template("student_form.html", mode="Add", values={})


@app.route("/students/<int:sid>/edit", methods=["GET", "POST"])
def edit_student(sid):
    student = db.get_student(sid) or abort(404)
    if request.method == "POST":
        data, errors = validate(request.form)
        if not errors:
            try:
                db.save_student(data, sid)
                flash("Student updated.", "success")
                return redirect(url_for("student_detail", sid=sid))
            except Exception:
                errors.append(f"Roll number {data['roll_no']} already exists.")
        for e in errors:
            flash(e, "error")
        return render_template("student_form.html", mode="Edit", values=request.form, sid=sid)
    values = {"roll_no": student["roll_no"], "name": student["name"], "branch": student["branch"]}
    values.update({f"m{i + 1}": m for i, m in enumerate(student["marks"])})
    return render_template("student_form.html", mode="Edit", values=values, sid=sid)


@app.route("/students/<int:sid>")
def student_detail(sid):
    student = db.get_student(sid) or abort(404)
    summary = analyzer.class_summary(db.all_students())
    avg = [x["average"] for x in summary["subject_stats"]]
    return render_template("student_detail.html", s=student, summary=summary,
                           rows=list(zip(analyzer.SUBJECTS, student["marks"], avg)))


@app.route("/students/<int:sid>/delete", methods=["POST"])
def delete_student(sid):
    db.delete_student(sid)
    flash("Student deleted.", "success")
    return redirect(url_for("students_list"))


# ---------------------------------------------------------------- CSV import
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename.lower().endswith(".csv"):
            flash("Please choose a .csv file.", "error")
            return redirect(url_for("upload"))
        return import_csv(io.StringIO(file.stream.read().decode("utf-8-sig")))
    return render_template("upload.html")


@app.route("/load-sample", methods=["POST"])
def load_sample():
    with open(os.path.join(app.root_path, "sample_data.csv"), encoding="utf-8") as f:
        return import_csv(f)


def import_csv(stream):
    reader = csv.DictReader(stream)
    if not reader.fieldnames:
        flash("The CSV file is empty.", "error")
        return redirect(url_for("upload"))
    header = {h.strip().lower(): h for h in reader.fieldnames}
    needed = ["roll_no", "name"] + [s.lower() for s in analyzer.SUBJECTS]
    missing = [n for n in needed if n not in header]
    if missing:
        flash("Missing column(s): " + ", ".join(missing), "error")
        return redirect(url_for("upload"))
    added = updated = skipped = 0
    for line_no, row in enumerate(reader, start=2):
        form = {"roll_no": row[header["roll_no"]], "name": row[header["name"]],
                "branch": row[header["branch"]] if "branch" in header else ""}
        for i, sub in enumerate(analyzer.SUBJECTS):
            form[f"m{i + 1}"] = row[header[sub.lower()]] or ""
        data, errors = validate(form)
        if errors:
            skipped += 1
            flash(f"Row {line_no} skipped: {errors[0]}", "error")
            continue
        if db.upsert_student(data) == "added":
            added += 1
        else:
            updated += 1
    flash(f"Import finished: {added} added, {updated} updated, {skipped} skipped.", "success")
    return redirect(url_for("students_list"))


# ------------------------------------------------------------------- exports
@app.route("/export/csv")
def export_csv():
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["rank", "roll_no", "name", "branch", *analyzer.SUBJECTS,
                "total", "percentage", "grade", "result"])
    for s in db.all_students():
        w.writerow([s["rank"], s["roll_no"], s["name"], s["branch"], *s["marks"],
                    s["total"], s["percentage"], s["grade"], s["result"]])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=results.csv"})


@app.route("/export/class-report.docx")
def export_class_report():
    students = db.all_students()
    summary = analyzer.class_summary(students)
    if not summary:
        flash("Add some students first.", "error")
        return redirect(url_for("dashboard"))
    return send_file(class_report_docx(students, summary), mimetype=DOCX_MIME,
                     as_attachment=True, download_name="class_result_report.docx")


@app.route("/students/<int:sid>/report.docx")
def export_student_report(sid):
    student = db.get_student(sid) or abort(404)
    summary = analyzer.class_summary(db.all_students())
    return send_file(student_report_docx(student, summary), mimetype=DOCX_MIME,
                     as_attachment=True, download_name=f"report_card_{student['roll_no']}.docx")


with app.app_context():
    db.init_db()

if __name__ == "__main__":
    app.run(debug=True)

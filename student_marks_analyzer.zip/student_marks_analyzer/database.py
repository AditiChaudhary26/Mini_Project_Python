"""database.py - SQLite helper functions."""
import sqlite3
from flask import g, current_app
import analyzer

N = len(analyzer.SUBJECTS)


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    cols = ", ".join(f"m{i + 1} INTEGER NOT NULL CHECK(m{i + 1} BETWEEN 0 AND {analyzer.MAX_MARKS})"
                     for i in range(N))
    get_db().execute(f"""CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT NOT NULL UNIQUE,
        name TEXT NOT NULL,
        branch TEXT NOT NULL DEFAULT '',
        {cols})""")
    get_db().commit()


def all_students():
    """Return every student, analysed and ranked."""
    rows = [dict(r) for r in get_db().execute("SELECT * FROM students")]
    return analyzer.rank_students([analyzer.analyse_student(r) for r in rows])


def get_student(student_id):
    """Return one analysed student with their class rank, or None."""
    for s in all_students():
        if s["id"] == student_id:
            return s
    return None


def save_student(data, student_id=None):
    """Insert (or update when student_id is given). data['marks'] is a list."""
    db = get_db()
    mcols = [f"m{i + 1}" for i in range(N)]
    if student_id is None:
        db.execute(f"INSERT INTO students (roll_no, name, branch, {', '.join(mcols)}) "
                   f"VALUES (?, ?, ?, {', '.join('?' * N)})",
                   [data["roll_no"], data["name"], data["branch"], *data["marks"]])
    else:
        sets = ", ".join(f"{c}=?" for c in mcols)
        db.execute(f"UPDATE students SET roll_no=?, name=?, branch=?, {sets} WHERE id=?",
                   [data["roll_no"], data["name"], data["branch"], *data["marks"], student_id])
    db.commit()


def upsert_student(data):
    """Used by CSV import: update the student if the roll number already exists."""
    db = get_db()
    row = db.execute("SELECT id FROM students WHERE roll_no=?", (data["roll_no"],)).fetchone()
    save_student(data, row["id"] if row else None)
    return "updated" if row else "added"


def delete_student(student_id):
    db = get_db()
    db.execute("DELETE FROM students WHERE id=?", (student_id,))
    db.commit()

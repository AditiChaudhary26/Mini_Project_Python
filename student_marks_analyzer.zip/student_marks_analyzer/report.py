"""report.py - Generates Word (.docx) reports using python-docx."""
from datetime import date
from io import BytesIO
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor
import analyzer


def _shade(cell, hex_fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_fill)
    tc_pr.append(shd)


def _table(doc, headers, rows):
    t = doc.add_table(rows=1, cols=len(headers))
    t.style = "Table Grid"
    for i, h in enumerate(headers):
        cell = t.rows[0].cells[i]
        cell.text = ""
        run = cell.paragraphs[0].add_run(h)
        run.bold = True
        run.font.color.rgb = RGBColor(255, 255, 255)
        _shade(cell, "1F4E79")
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            cells[i].text = str(v)
    return t


def _base_document(title):
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(11)
    h = doc.add_heading(title, level=0)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p = doc.add_paragraph(f"Generated on {date.today().strftime('%d %B %Y')}")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return doc


def class_report_docx(students, summary):
    """Full class result report -> BytesIO."""
    doc = _base_document("Class Result Analysis Report")

    doc.add_heading("1. Summary", level=1)
    top = summary["topper"]
    _table(doc, ["Measure", "Value"], [
        ("Total students", summary["count"]),
        ("Passed / Failed", f"{summary['passed']} / {summary['failed']}"),
        ("Pass percentage", f"{summary['pass_percent']}%"),
        ("Class average", f"{summary['average_percentage']}%"),
        ("Median", f"{summary['median_percentage']}%"),
        ("Standard deviation", summary["std_dev"]),
        ("Topper", f"{top['name']} ({top['roll_no']}) - {top['percentage']}%"),
        ("Strongest subject", summary["best_subject"]),
        ("Weakest subject", summary["weakest_subject"]),
    ])

    doc.add_heading("2. Subject-wise Analysis", level=1)
    _table(doc, ["Subject", "Average", "Highest", "Lowest", "Pass %"],
           [(s["subject"], s["average"], s["highest"], s["lowest"], s["pass_percent"])
            for s in summary["subject_stats"]])

    doc.add_heading("3. Grade Distribution", level=1)
    _table(doc, ["Grade", "Students"], list(summary["grade_counts"].items()))

    doc.add_heading("4. Rank List", level=1)
    _table(doc, ["Rank", "Roll No", "Name", "Total", "%", "Grade", "Result"],
           [(s["rank"], s["roll_no"], s["name"], s["total"], s["percentage"],
             s["grade"], s["result"]) for s in students])

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf


def student_report_docx(s, summary):
    """Individual report card -> BytesIO."""
    doc = _base_document("Student Report Card")
    doc.add_paragraph(f"Name: {s['name']}")
    doc.add_paragraph(f"Roll No: {s['roll_no']}")
    doc.add_paragraph(f"Branch: {s['branch'] or '-'}")

    doc.add_heading("Marks Obtained", level=1)
    avg = {x["subject"]: x["average"] for x in summary["subject_stats"]}
    rows = []
    for sub, m in zip(analyzer.SUBJECTS, s["marks"]):
        status = "Pass" if m >= analyzer.PASS_MARKS else "Fail"
        rows.append((sub, f"{m} / {analyzer.MAX_MARKS}", avg[sub], status))
    _table(doc, ["Subject", "Marks", "Class Average", "Status"], rows)

    doc.add_heading("Overall Result", level=1)
    _table(doc, ["Total", "Percentage", "Grade", "Class Rank", "Result"],
           [(f"{s['total']} / {analyzer.MAX_MARKS * len(analyzer.SUBJECTS)}",
             f"{s['percentage']}%", s["grade"],
             f"{s['rank']} of {summary['count']}", s["result"])])
    if s["failed_subjects"]:
        doc.add_paragraph("Needs improvement in: " + ", ".join(s["failed_subjects"]))

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf
